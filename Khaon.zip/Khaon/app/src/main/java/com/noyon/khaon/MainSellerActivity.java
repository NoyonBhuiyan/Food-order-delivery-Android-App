package com.shawon.groceryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MainSellerActivity extends AppCompatActivity {
    private TextView nameTv,shopNameTv,emailTv,tabProductsTv,tabOdersTv,filterProductsTv,filteredOrdersTV;
    private ImageButton logOutBtn ,editProfileBtn,addProductBtn,filterProductBtn ,filterOrderBtn,moreBtn;
    private EditText searchProductEt;
    private ImageView profileTv;
    private RelativeLayout ordersRl,productsRl;
    private RecyclerView productsRv, ordersRV;
    private FirebaseAuth firebaseAuth;

    private ArrayList<ModelProduct> productList;
    private AdapterProductSeller adapterProductSeller;

    private ArrayList<ModelOrderShop> orderShopArrayList;
    private AdapterOrderShop adapterOrderShop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_seller);

        nameTv = findViewById(R.id.nameTv);
        logOutBtn = findViewById(R.id.logOutBtn);
        editProfileBtn = findViewById(R.id.editProfileBtn);
        shopNameTv = findViewById(R.id.shopNameTv);
        emailTv = findViewById(R.id.emailTv);
        addProductBtn = findViewById(R.id.addProductBtn);
        profileTv = findViewById(R.id.profileTv);
        tabProductsTv = findViewById(R.id.tabProductsTv);
        tabOdersTv = findViewById(R.id.tabOdersTv);
        ordersRl = findViewById(R.id.ordersRl);
        productsRl = findViewById(R.id.productsRl);
        searchProductEt = findViewById(R.id.searchProductEt);
        filterProductBtn = findViewById(R.id.filterProductBtn);
        filterProductsTv = findViewById(R.id.filterProductsTv);
        productsRv = findViewById(R.id.productsRv);
        filteredOrdersTV= findViewById( R.id.filteredOrdersTV );
        filterOrderBtn=findViewById( R.id.filterOrderBtn );
        ordersRV= findViewById( R.id.ordersRV );

        moreBtn=findViewById( R.id.moreBtn );

        firebaseAuth = FirebaseAuth.getInstance();
        checkUser();
        showProductsUI();
        loadAllProducts();
        loadAllOrders();

        searchProductEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                try{
                    adapterProductSeller.getFilter().filter(charSequence);
                }
                catch (Exception e){
                        e.printStackTrace();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        logOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signOut();
                checkUser();
            }
        });

        editProfileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //edit seller profile
                Intent intent = new Intent(MainSellerActivity.this,ProfileEditSellerActivity.class);
                startActivity(intent);

            }
        });

        addProductBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //open edit product activity
                Intent intent = new Intent(MainSellerActivity.this,AddProductActivity.class);
                startActivity(intent);

            }
        });
        tabOdersTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //load orders
                showOrdersrUI();

            }
        });
        tabProductsTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               //load products
                showProductsUI();
            }
        });
        filterProductBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainSellerActivity.this);
                builder.setTitle("Choose Category:")
                        .setItems(Constants.productCategories1, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                 String selected = Constants.productCategories1[i];
                                 filterProductsTv.setText(selected);
                                 if(selected.equals("All")){
                                     //lodd all
                                     loadAllProducts();
                                 }else {
                                     loadFilterProducts(selected);
                                 }
                            }
                        })
                        .show();
            }
        });

        filterOrderBtn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String[] options={"All", "In Progress", "Completed", "Cancelled"};
                AlertDialog.Builder builder= new AlertDialog.Builder( MainSellerActivity.this );
                builder.setTitle( "Filter Orders:" )
                        .setItems( options, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                if (i==0){
                                    filteredOrdersTV.setText( "Showing All Orders" );
                                    adapterOrderShop.getFilter().filter( "" );
                                }else {
                                    String optionClicked= options[i];
                                    filteredOrdersTV.setText( "Showing"+optionClicked+" Orders" );
                                    adapterOrderShop.getFilter().filter( optionClicked );

                                }
                            }
                        } ).show();
            }
        } );


//        MoreOptions

        final PopupMenu popupMenu= new PopupMenu( MainSellerActivity.this, moreBtn );

        popupMenu.getMenu().add( "Settings" );
        popupMenu.getMenu().add( "Promotions" );

        popupMenu.setOnMenuItemClickListener( new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {

                if (menuItem.getTitle() == "Settings"){
                    startActivity( new Intent( MainSellerActivity.this, SettingsActivity.class ) );
                }else if( menuItem.getTitle() == "Promotions") {
                    startActivity( new Intent( MainSellerActivity.this, PromotionCodesActivity.class ) );
                }
                return true;
            }
        } );

moreBtn.setOnClickListener( new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        popupMenu.show();

    }
} );


    }

    private void loadAllOrders() {
orderShopArrayList= new ArrayList<>(  );

DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Users");
ref.child( firebaseAuth.getUid()).child( "Orders" )
        .addValueEventListener( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                orderShopArrayList.clear();
                for (DataSnapshot ds:snapshot.getChildren()){
                    ModelOrderShop modelOrderShop= ds.getValue(ModelOrderShop.class);

                    orderShopArrayList.add( modelOrderShop );
                }
                adapterOrderShop= new AdapterOrderShop( MainSellerActivity .this, orderShopArrayList);

                ordersRV.setAdapter( adapterOrderShop );

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        } );


    }

    private void loadFilterProducts(final String selected) {
        productList = new ArrayList<>();
        //get all products
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(firebaseAuth.getUid()).child("Products")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //before getting reset list
                        productList.clear();
                        for(DataSnapshot ds: snapshot.getChildren()){
                            String productCategory = ""+ds.child("productCategory").getValue();
                            //if selected category matches product category then add in list
                            if(selected.equals(productCategory)){
                                ModelProduct modelProduct = ds.getValue(ModelProduct.class);
                                productList.add(modelProduct);
                            }
                        }
                        //setup adapter
                        adapterProductSeller = new AdapterProductSeller(MainSellerActivity.this,productList);
                        //set adapter
                        productsRv.setAdapter(adapterProductSeller);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void loadAllProducts() {
        productList = new ArrayList<>();
        //get all products
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(firebaseAuth.getUid()).child("Products")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //before getting reset list
                        productList.clear();
                        for(DataSnapshot ds: snapshot.getChildren()){
                            ModelProduct modelProduct = ds.getValue(ModelProduct.class);
                            productList.add(modelProduct);
                        }
                          //setup adapter
                        adapterProductSeller = new AdapterProductSeller(MainSellerActivity.this,productList);
                        //set adapter
                        productsRv.setAdapter(adapterProductSeller);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void showProductsUI() {
        //show products ui and hide order ui
        productsRl.setVisibility(View.VISIBLE);
        ordersRl.setVisibility(View.GONE);
        tabProductsTv.setTextColor(getResources().getColor(R.color.colorBlack));
        tabProductsTv.setBackgroundResource(R.drawable.shape_rect04);

        tabOdersTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabOdersTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));
    }

    private void showOrdersrUI() {
        //show orders ui and hide products ui
        productsRl.setVisibility(View.GONE);
        ordersRl.setVisibility(View.VISIBLE);

        tabProductsTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabProductsTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        tabOdersTv.setTextColor(getResources().getColor(R.color.colorBlack));
        tabOdersTv.setBackgroundResource(R.drawable.shape_rect04);
    }





    private void checkUser() {
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
        if(firebaseUser == null){
            Intent intent = new Intent(MainSellerActivity.this,LoginActivity.class);
            startActivity(intent);
            finish();
        }else {
            loadMyInfo();
        }
    }

    private void loadMyInfo() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("uid").equalTo(firebaseAuth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot ds: dataSnapshot.getChildren()){
                            String name = ""+ds.child("name").getValue();
                            String email = ""+ds.child("email").getValue();
                            String accountType = ""+ds.child("accountType").getValue();
                            String shopName = ""+ds.child("shopName").getValue();
                            String profileImage = ""+ds.child("profileImage").getValue();


                            nameTv.setText(name);
                            shopNameTv.setText(shopName);
                            emailTv.setText(email);
                            try{
                                Picasso.get().load(profileImage).placeholder(R.drawable.ic_person_white).into(profileTv);
                            }catch(Exception e){
                                profileTv.setImageResource(R.drawable.ic_person_white);
                            }

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }
}
