package com.shawon.groceryapp;

public class Constants {

    public static final String FCM_KEY = "AAAADwVs5kg:APA91bFVYpbiLUCIk26hV98aBDw6FnyUis__ZuLZdH4-kuUyQM3RwloLz_RC4wir9UuLKGmlgVdnSLj2LSi3pmp5uoahLd_eJWGps1TY3tNoKv-hFmpQogW_aOsO1QBZBcpi6v8c_m8e";
    public static final String FCM_TOPIC ="PUSH_NOTIFICATIONS";

   public static final String [] productCategories ={
      "Appetizer",
      "Salad",
      "Soup",
      "Seasonal Juice",
      "Burger",
      "Pasta",
      "Chowmein",
      "Sizzling",
      "Curry",
      "Set Menu",
      "Beverages",
      "Desserts"
    };

    public static final String [] productCategories1 ={
            "All",
            "Appetizer",
            "Salad",
            "Soup",
            "Seasonal Juice",
            "Burger",
            "Pasta",
            "Sizzling",
            "Curry",
            "Set Menu",
            "Beverages",
            "Desserts",
            "Desserts"
    };
}
