package com.shawon.groceryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.HashMap;

public class AddPromoCodesActivity extends AppCompatActivity {
private ImageButton backBtn;
private Button addBtn;
private TextView expireDateTv;
private EditText promoCodeEt,promoDescriptionEt,promoPriceEt,minimumOrderPricEt;

FirebaseAuth firebaseAuth;
ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_add_promo_codes );

        backBtn= findViewById( R.id.backBtn);
        addBtn= findViewById( R.id.addBtn );
        promoCodeEt= findViewById( R.id.promoCodeEt);
        promoDescriptionEt= findViewById( R.id.promoDescriptionEt);
        promoPriceEt= findViewById( R.id.promoPriceEt);
        minimumOrderPricEt= findViewById( R.id.minimumOrderPricEt);
        expireDateTv= findViewById( R.id.expireDateTv );

        firebaseAuth = FirebaseAuth.getInstance();
        progressDialog= new ProgressDialog( this );
        progressDialog.setTitle( "Please Wait" );
        progressDialog.setCanceledOnTouchOutside( false );



        backBtn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();

            }
        } );

        expireDateTv.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             datePickDialog();
            }
        } );

        addBtn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              inputData();
            }
        } );

    }

    private void datePickDialog() {

        Calendar calendar= Calendar.getInstance();
        int mYear= calendar.get( Calendar.YEAR );
        int mMonth= calendar.get( Calendar.MONTH );
        int mDay= calendar.get( Calendar.DAY_OF_MONTH );

        DatePickerDialog datePickerDialog= new DatePickerDialog( this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {

                DecimalFormat decimalFormat= new DecimalFormat( "00" );
                String pDay= decimalFormat.format(dayOfMonth);
                String pMonth= decimalFormat.format(monthOfYear);
                String pYear=""+year;
                String pDate= pDay+"/"+pMonth+"/"+pYear;

                expireDateTv.setText( pDate );

            }
        } ,mYear, mMonth , mDay);
        datePickerDialog.show();

        datePickerDialog.getDatePicker().setMinDate( System.currentTimeMillis()-1000 );


    }


    private String description, promoCode, promoPrice, mimimumOrderPrice,expireDate;
    private void inputData(){

        promoCode= promoCodeEt.getText().toString().trim();
        description= promoDescriptionEt.getText().toString().trim();
        promoPrice= promoPriceEt.getText().toString().trim();
        mimimumOrderPrice= minimumOrderPricEt.getText().toString().trim();
        expireDate= expireDateTv.getText().toString().trim();


        addDataToDb();
    }

    private void addDataToDb() {
        progressDialog.setMessage( "Adding Promotion Code..." );
        progressDialog.show();

        String timestamp= ""+System.currentTimeMillis();

        HashMap<String, Object> hashMap= new HashMap<>(  );
        hashMap.put( "id", "" + timestamp );
        hashMap.put( "timestamp", "" + timestamp );
        hashMap.put( "description", "" + description );
        hashMap.put( "promoCode", "" + promoCode );
        hashMap.put( "promoPrice", "" + promoPrice );
        hashMap.put( "mimimumOrderPrice", "" + mimimumOrderPrice );
        hashMap.put( "expireDate", "" + expireDate );

        DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Users");
        ref.child(firebaseAuth.getUid()).child( "Promotions" ).child( timestamp )
                .setValue( hashMap )
                .addOnSuccessListener( new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        progressDialog.dismiss();
                        Toast.makeText( AddPromoCodesActivity.this, "Promotion Code Added", Toast.LENGTH_SHORT ).show();

                    }
                } )
                .addOnFailureListener( new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText( AddPromoCodesActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT ).show();

                    }
                } );


    }
}