package com.shawon.groceryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MainUserActivity extends AppCompatActivity {
    private TextView nameTv,emailTv,phoneTv,tabShopsTv,tabOdersTv;
    private ImageButton logOutBtn,editProfileBtn,settingsBtn;
    private ImageView profileTv;
    private RelativeLayout shopsRl,ordersRl;
    private FirebaseAuth firebaseAuth;
    private RecyclerView shopsRv,ordersRv;
    private ArrayList<ModelShop> shopList;
    private AdapterShop adapterShop;

    private ArrayList<ModelOrderUser> ordersList;
    private AdapterOrderUser adapterOrderUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_user);
        nameTv = findViewById(R.id.nameTv);
        emailTv = findViewById(R.id.emailTv);
        phoneTv = findViewById(R.id.phoneTv);
        tabShopsTv = findViewById(R.id.tabShopsTv);
        tabOdersTv = findViewById(R.id.tabOdersTv);
        logOutBtn = findViewById(R.id.logOutBtn);
        editProfileBtn = findViewById(R.id.editProfileBtn);
        profileTv = findViewById(R.id.profileTv);
        shopsRl = findViewById(R.id.shopsRl);
        ordersRl  = findViewById(R.id.ordersRl);
        shopsRv  = findViewById(R.id.shopsRv);
        ordersRv  = findViewById(R.id.ordersRv);
        settingsBtn= findViewById( R.id.settingsBtn );
        firebaseAuth = FirebaseAuth.getInstance();
        checkUser();
        showShopsUI();

        logOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signOut();
                checkUser();
            }
        });

        editProfileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //open edit profile
                Intent intent = new Intent(MainUserActivity.this,ProfileEditUserActivity.class);
                startActivity(intent);
                finish();
            }
        });

        tabShopsTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showShopsUI();
            }
        });
        tabOdersTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showOrdersrUI();
            }
        });

        settingsBtn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity( new Intent( MainUserActivity.this, SettingsActivity.class ) );


            }
        } );

    }

    private void showShopsUI() {
        //show products ui and hide order ui
        shopsRl.setVisibility(View.VISIBLE);
        ordersRl.setVisibility(View.GONE);
        tabShopsTv.setTextColor(getResources().getColor(R.color.colorBlack));
        tabShopsTv.setBackgroundResource(R.drawable.shape_rect04);

        tabOdersTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabOdersTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));
    }

    private void showOrdersrUI() {
        //show orders ui and hide products ui
        shopsRl.setVisibility(View.GONE);
        ordersRl.setVisibility(View.VISIBLE);

        tabShopsTv.setTextColor(getResources().getColor(R.color.colorWhite));
        tabShopsTv.setBackgroundColor(getResources().getColor(android.R.color.transparent));

        tabOdersTv.setTextColor(getResources().getColor(R.color.colorBlack));
        tabOdersTv.setBackgroundResource(R.drawable.shape_rect04);
    }

    private void checkUser() {
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
        if(firebaseUser == null){
            Intent intent = new Intent(MainUserActivity.this,LoginActivity.class);
            startActivity(intent);
            finish();
        }else {
            loadMyInfo();
        }
    }

    private void loadMyInfo() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("uid").equalTo(firebaseAuth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot ds: dataSnapshot.getChildren()){
                            String name = ""+ds.child("name").getValue();
                            String email = ""+ds.child("email").getValue();
                            String phone = ""+ds.child("phone").getValue();
                            String profileImage = ""+ds.child("profileImage").getValue();
                            String city = ""+ds.child("city").getValue();
                            String accountType = ""+ds.child("accountType").getValue();

                            nameTv.setText(name);
                            emailTv.setText(email);
                            phoneTv.setText(phone);
                            try{
                                Picasso.get().load(profileImage).placeholder(R.drawable.ic_person_white).into(profileTv);
                            }catch (Exception e){
                               profileTv.setImageResource(R.drawable.ic_person_white);
                            }
                            loadShops(city);
                            loadOrders();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }

    private void loadOrders() {
        ordersList = new ArrayList<>();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                   ordersList.clear();
                   for(DataSnapshot ds: snapshot.getChildren()){
                       String uid = ""+ds.getRef().getKey();

                       DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users").child(uid).child("Orders");
                       ref.orderByChild("orderBy").equalTo(firebaseAuth.getUid())
                               .addValueEventListener(new ValueEventListener() {
                                   @Override
                                   public void onDataChange(@NonNull DataSnapshot snapshot) {
                                             if(snapshot.exists()){
                                                 for(DataSnapshot ds: snapshot.getChildren()){
                                                     ModelOrderUser modelOrderUser = ds.getValue(ModelOrderUser.class);
                                                     ordersList.add(modelOrderUser);
                                                 }
                                                 adapterOrderUser = new AdapterOrderUser(MainUserActivity.this,ordersList);
                                                 ordersRv.setAdapter(adapterOrderUser);
                                             }
                                   }

                                   @Override
                                   public void onCancelled(@NonNull DatabaseError error) {

                                   }
                               });
                   }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void loadShops(final String city) {
        shopList = new ArrayList<>();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.orderByChild("accountType").equalTo("Seller")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                              // clear list before adding
                        shopList.clear();
                        for (DataSnapshot ds: snapshot.getChildren()){
                            ModelShop modelShop = ds.getValue(ModelShop.class);

                            String shopcity =""+ds.child("city").getValue();
                            if(shopcity.equals(city)){
                                //show only user city shop
                                shopList.add(modelShop);
                            }
                            //if i want to display all shops, skip if condition and add
                            //shopList.add(modelShop);
                        }
                       //setup adapter
                        adapterShop = new AdapterShop(MainUserActivity.this,shopList);
                        //setup adapter to recyelerview
                        shopsRv.setAdapter(adapterShop);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
}
