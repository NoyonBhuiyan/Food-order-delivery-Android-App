package com.shawon.groceryapp;

public class ModelShop {
    private String uid, email,shopName,name,phone,deliveryFee,country,state,city,address,pass,
            confirmPass,timetamp,accountType,shopOpen,online,profileImage;

    public ModelShop() {
    }

    public ModelShop(String uid, String email, String shopName, String name, String phone, String deliveryFee,
                     String country, String state, String city, String address, String pass, String confirmPass,
                     String timetamp, String accountType, String shopOpen, String online, String profileImage) {
        this.uid = uid;
        this.email = email;
        this.shopName = shopName;
        this.name = name;
        this.phone = phone;
        this.deliveryFee = deliveryFee;
        this.country = country;
        this.state = state;
        this.city = city;
        this.address = address;
        this.pass = pass;
        this.confirmPass = confirmPass;
        this.timetamp = timetamp;
        this.accountType = accountType;
        this.shopOpen = shopOpen;
        this.online = online;
        this.profileImage = profileImage;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDeliveryFee() {
        return deliveryFee;
    }

    public void setDeliveryFee(String deliveryFee) {
        this.deliveryFee = deliveryFee;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getConfirmPass() {
        return confirmPass;
    }

    public void setConfirmPass(String confirmPass) {
        this.confirmPass = confirmPass;
    }

    public String getTimetamp() {
        return timetamp;
    }

    public void setTimetamp(String timetamp) {
        this.timetamp = timetamp;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getShopOpen() {
        return shopOpen;
    }

    public void setShopOpen(String shopOpen) {
        this.shopOpen = shopOpen;
    }

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }
}
