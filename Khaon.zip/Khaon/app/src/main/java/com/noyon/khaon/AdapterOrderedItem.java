package com.shawon.groceryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterOrderedItem extends RecyclerView.Adapter<AdapterOrderedItem.HolderOrderedItem> {
    private Context context;
    private ArrayList<ModelOrderedItem> orderedItemList;

    public AdapterOrderedItem(Context context, ArrayList<ModelOrderedItem> orderedItemList) {
        this.context = context;
        this.orderedItemList = orderedItemList;
    }

    @NonNull
    @Override
    public HolderOrderedItem onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.row_ordereditem,parent,false);
        return new HolderOrderedItem(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderOrderedItem holder, int position) {
        ModelOrderedItem modelOrderedItem = orderedItemList.get(position);
        String pId = modelOrderedItem.getpId();
        String name = modelOrderedItem.getName();
        String cost = modelOrderedItem.getCost();
        String price = modelOrderedItem.getPrice();
        String quantity = modelOrderedItem.getQuantity();

        holder.itemTitleTv.setText(name);
        holder.itemPriceEachTv.setText("TK"+price);
        holder.itemPriceTv.setText("Tk"+cost);
        holder.itemQuantityTv.setText("("+quantity+")");

    }

    @Override
    public int getItemCount() {
        return orderedItemList.size();
    }

    class HolderOrderedItem extends RecyclerView.ViewHolder{

       private TextView itemTitleTv,itemPriceTv,itemPriceEachTv,itemQuantityTv;
        public HolderOrderedItem(@NonNull View itemView) {
            super(itemView);

            itemTitleTv= itemView.findViewById(R.id.itemTitleTv);
            itemPriceTv= itemView.findViewById(R.id.itemPriceTv);
            itemPriceEachTv= itemView.findViewById(R.id.itemPriceEachTv);
            itemQuantityTv= itemView.findViewById(R.id.itemQuantityTv);

        }
    }
}
