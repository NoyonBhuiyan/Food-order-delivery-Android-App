package com.shawon.groceryapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class RegisterSellerActivity extends AppCompatActivity  {
 private ImageButton backBtn,gpsBtn;
 private ImageView profile_image;
 private EditText sellerName,shopName,phone,delevery,country,state,
          city,address1,regEmail,regPass,regPassCon;
 private Button regBtn;
 //permission constant
    //private static final int LOCATION_REQUEST_CODE=100;
    private static final int CAMERA_REQUEST_CODE=200;
    private static final int STORAGE_REQUEST_CODE=300;
    private static final int IMAGE_PICK_GALLERY_CODE=400;
    private static final int IMAGE_PICK_CAMERA_CODE=500;
    //permission arrays
    //private String [] locationPermissions;
    private String [] cameraPermissions;
    private String [] storagePermissions;
    private Uri image_uri;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog pDialog;

//    private LocationManager locationManager;
//    private double latitude,longitude;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_seller);

        backBtn= findViewById(R.id.backBtn);
       // gpsBtn= findViewById(R.id.gpsBtn);
        profile_image= findViewById(R.id.profile_image);
        sellerName= findViewById(R.id.sellerName);
        shopName= findViewById(R.id.shopName);
        phone= findViewById(R.id.phone);
        delevery= findViewById(R.id.delevery);
        country= findViewById(R.id.country);
        state= findViewById(R.id.state);
        city= findViewById(R.id.city);
        address1= findViewById(R.id.address1);
        regEmail= findViewById(R.id.regEmail);
        regPass= findViewById(R.id.regPass);
        regPassCon= findViewById(R.id.regPassCon);
        regBtn= findViewById(R.id.regBtn);

       // locationPermissions = new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
        cameraPermissions = new String[]{Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE};
        storagePermissions = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};

        firebaseAuth = FirebaseAuth.getInstance();
        pDialog = new ProgressDialog(this);
        pDialog.setTitle("Please Wait...");
        pDialog.setCanceledOnTouchOutside(false);

        profile_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImagePickDialog();
            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                Intent intent = new Intent(RegisterSellerActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

//        gpsBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if(checkLocationPermission()){
//                      detectLocation();
//                }else {
//                    requestLocationPermission();
//                }
//            }
//        });

        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //seller registration
                inputData();
            }
        });

    }

    private String sellName,shop,PhoneNumber,deliveryFee,county,stat,cit,add,email,pass,confirmPass;
    private void inputData() {
        sellName = sellerName.getText().toString().trim();
        shop = shopName.getText().toString().trim();
        PhoneNumber = phone.getText().toString().trim();
        deliveryFee = delevery.getText().toString().trim();
        county = country.getText().toString().trim();
        stat = state.getText().toString().trim();
        cit = city.getText().toString().trim();
        add = address1.getText().toString().trim();
        email = regEmail.getText().toString().trim();
        pass = regPass.getText().toString().trim();
        confirmPass = regPassCon.getText().toString().trim();
        //validation data

        if(TextUtils.isEmpty(sellName)){
            Toast.makeText(this, "Enter Name", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(shop)){
            Toast.makeText(this, "Enter shop name", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(PhoneNumber)){
            Toast.makeText(this, "Enter phone Number..", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(deliveryFee)){
            Toast.makeText(this, "Enter delivery fee", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(county)){
            Toast.makeText(this, "Enter country", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(stat)){
            Toast.makeText(this, "Enter state", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(cit)){
            Toast.makeText(this, "Enter city", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(add)){
            Toast.makeText(this, "Enter Address", Toast.LENGTH_SHORT).show();
            return;
        }
        if( !Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            Toast.makeText(this, "Invalid Email...", Toast.LENGTH_SHORT).show();
            return;
        }
        if(pass.length()>6){
            Toast.makeText(this, "Password at least 6 characters...", Toast.LENGTH_SHORT).show();
            return;
        }
        if( !pass.equals(confirmPass)){
            Toast.makeText(this, "Password does't match...", Toast.LENGTH_SHORT).show();
            return;
        }
        createAccount();
    }

    private void createAccount() {
        pDialog.setMessage("creating Account....");
        pDialog.show();
        //create account
        firebaseAuth.createUserWithEmailAndPassword(email,pass).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                //account created
                saveFirebaseData();

                //saveFirebaseData2();
            }
        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        //failed creating account
                        pDialog.dismiss();
                        Toast.makeText(RegisterSellerActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });
    }

    private void saveFirebaseData() {
        pDialog.setMessage("saving account info...");
        final String timetamp = ""+System.currentTimeMillis();
        if(image_uri == null){
            //save info without image
            //save data
            HashMap<String,Object> hashMap = new HashMap<>();
            hashMap.put("uid",""+firebaseAuth.getUid());
            hashMap.put("email",""+email);
            hashMap.put("shopName",""+shop);
            hashMap.put("name",""+sellName);
            hashMap.put("phone",""+PhoneNumber);
            hashMap.put("deliveryFee",""+deliveryFee);
            hashMap.put("country",""+county);
            hashMap.put("state",""+stat);
            hashMap.put("city",""+cit);
            hashMap.put("address",""+add);
            hashMap.put("pass",""+pass);
            hashMap.put("confirmPass",""+confirmPass);
            hashMap.put("timetamp",""+timetamp);
            hashMap.put("accountType",""+"Seller");
            hashMap.put("shopOpen",""+"true");
            hashMap.put("online",""+"true");
            hashMap.put("profileImage",""+"");
            //save to db
            DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Users");
            ref.child(firebaseAuth.getUid()).setValue(hashMap)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            pDialog.dismiss();
                            Intent intent = new Intent(RegisterSellerActivity.this, MainSellerActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            pDialog.dismiss();
                            Toast.makeText(RegisterSellerActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    });

        }else {
            //save info with image
            //name and path of image
            String filePathName ="profile_image"+""+firebaseAuth.getUid();
            //upload
            StorageReference storageReference = FirebaseStorage.getInstance().getReference(filePathName);
            storageReference.putFile(image_uri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            //get uri upload
                            Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                            while (!uriTask.isSuccessful());
                            Uri downloadImageUri = uriTask.getResult();
                            if(uriTask.isSuccessful()){
                                HashMap<String,Object> hashMap = new HashMap<>();
                                hashMap.put("uid",""+firebaseAuth.getUid());
                                hashMap.put("email",""+email);
                                hashMap.put("shopName",""+shop);
                                hashMap.put("name",""+sellName);
                                hashMap.put("phone",""+PhoneNumber);
                                hashMap.put("deliveryFee",""+deliveryFee);
                                hashMap.put("country",""+county);
                                hashMap.put("state",""+stat);
                                hashMap.put("city",""+cit);
                                hashMap.put("address",""+add);
                                hashMap.put("pass",""+pass);
                                hashMap.put("confirmPass",""+confirmPass);
                                hashMap.put("timetamp",""+timetamp);
                                hashMap.put("accountType",""+"Seller");
                                hashMap.put("shopOpen",""+"true");
                                hashMap.put("online",""+"true");
                                hashMap.put("profileImage",""+downloadImageUri);
                                //save to db
                                DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Users");
                                ref.child(firebaseAuth.getUid()).setValue(hashMap)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                pDialog.dismiss();
                                                Log.d("myTag", "This is my message");
                                                Intent intent =new Intent(RegisterSellerActivity.this,MainSellerActivity.class);
                                                startActivity(intent);
                                                finish();
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                pDialog.dismiss();
                                                Toast.makeText(RegisterSellerActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();

                                            }
                                        });
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                        }
                    });
        }
    }
//    private void saveFirebaseData2() {
//        pDialog.setMessage("saving account info...");
//        final String timetamp = ""+System.currentTimeMillis();
//        if(image_uri == null){
//            //save info without image
//            //save data
//            HashMap<String,Object> hashMap = new HashMap<>();
//            hashMap.put("uid",""+firebaseAuth.getUid());
//            hashMap.put("email",""+email);
//            hashMap.put("name",""+sellName);
//            hashMap.put("phone",""+PhoneNumber);
//            hashMap.put("country",""+county);
//            hashMap.put("state",""+stat);
//            hashMap.put("city",""+cit);
//            hashMap.put("address",""+add);
//            hashMap.put("pass",""+pass);
//            hashMap.put("confirmPass",""+confirmPass);
//            hashMap.put("timetamp",""+timetamp);
//            hashMap.put("accountType",""+"User");
//            hashMap.put("shopOpen",""+"true");
//            hashMap.put("online",""+"true");
//            hashMap.put("profileImage",""+"");
//            //save to db
//            DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Users");
//            ref.child(firebaseAuth.getUid()).setValue(hashMap)
//                    .addOnSuccessListener(new OnSuccessListener<Void>() {
//                        @Override
//                        public void onSuccess(Void aVoid) {
//                            pDialog.dismiss();
//                            Intent intent =new Intent(RegisterSellerActivity.this,MainSellerActivity.class);
//                            startActivity(intent);
//                            finish();
//                        }
//                    })
//                    .addOnFailureListener(new OnFailureListener() {
//                        @Override
//                        public void onFailure(@NonNull Exception e) {
//                            pDialog.dismiss();
//                            Toast.makeText(RegisterSellerActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
//
//                        }
//                    });
//
//        }else {
//            //save info with image
//            //name and path of image
//            String filePathName ="profile_image"+""+firebaseAuth.getUid();
//            //upload
//            StorageReference storageReference = FirebaseStorage.getInstance().getReference(filePathName);
//            storageReference.putFile(image_uri)
//                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
//                        @Override
//                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
//                            //get uri upload
//                            Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
//                            while (!uriTask.isSuccessful());
//                            Uri downloadImageUri = uriTask.getResult();
//                            if(uriTask.isSuccessful()){
//                                HashMap<String,Object> hashMap = new HashMap<>();
//                                hashMap.put("uid",""+firebaseAuth.getUid());
//                                hashMap.put("email",""+email);
//                                hashMap.put("name",""+sellName);
//                                hashMap.put("phone",""+PhoneNumber);
//                                hashMap.put("country",""+county);
//                                hashMap.put("state",""+stat);
//                                hashMap.put("city",""+cit);
//                                hashMap.put("address",""+add);
//                                hashMap.put("pass",""+pass);
//                                hashMap.put("confirmPass",""+confirmPass);
//                                hashMap.put("timetamp",""+timetamp);
//                                hashMap.put("accountType",""+"User");
//                                hashMap.put("shopOpen",""+"true");
//                                hashMap.put("profileImage",""+downloadImageUri);
//                                //save to db
//                                DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Users");
//                                ref.child(firebaseAuth.getUid()).setValue(hashMap)
//                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
//                                            @Override
//                                            public void onSuccess(Void aVoid) {
//                                                pDialog.dismiss();
//                                                Intent intent =new Intent(RegisterSellerActivity.this,MainSellerActivity.class);
//                                                startActivity(intent);
//                                            }
//                                        })
//                                        .addOnFailureListener(new OnFailureListener() {
//                                            @Override
//                                            public void onFailure(@NonNull Exception e) {
//                                                pDialog.dismiss();
//                                                Toast.makeText(RegisterSellerActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
//
//                                            }
//                                        });
//                            }
//                        }
//                    })
//                    .addOnFailureListener(new OnFailureListener() {
//                        @Override
//                        public void onFailure(@NonNull Exception e) {
//
//                        }
//                    });
//        }
//    }

    private void showImagePickDialog() {
        String [] options = {"Camera","Gallery"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pick the Image")
                .setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                            if(i == 0){
                                //camera clicked
                                if(checkCameraPermission()){
                                    //permission allowed
                                    pickFromCamera();
                                }else {
                                    //not allowed
                                    requestCameraPermission();
                                }
                            }else{
                                //gallery clicked
                                if(checkStoragePermission()){
                                    //permission allowed
                                    pickFromGallery();

                                }else {
                                    //not allowed
                                    requestStoragePermission();
                                }
                            }
                    }
                })
                .show();
    }
    private void pickFromGallery(){
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent,IMAGE_PICK_GALLERY_CODE);
    }
    private void pickFromCamera(){
        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.Images.Media.TITLE,"Temp_Image Title");
        contentValues.put(MediaStore.Images.Media.DESCRIPTION,"Temp_Image Description");
        image_uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,contentValues);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT,image_uri);
        startActivityForResult(intent,IMAGE_PICK_CAMERA_CODE);
    }


//    private void detectLocation() {
//        Toast.makeText(this, "please wait....", Toast.LENGTH_LONG).show();
//        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
//        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0,this);
//    }

    private boolean checkStoragePermission(){
        boolean result = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                (PackageManager.PERMISSION_GRANTED);
        return  result;
    }
    private  void requestStoragePermission(){
        ActivityCompat.requestPermissions(this,storagePermissions,STORAGE_REQUEST_CODE);
    }

    private boolean checkCameraPermission(){
        boolean result = ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==
                (PackageManager.PERMISSION_GRANTED);
        boolean result1 = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==
                (PackageManager.PERMISSION_GRANTED);
        return  result && result1;
    }
    private  void requestCameraPermission(){
        ActivityCompat.requestPermissions(this,cameraPermissions,CAMERA_REQUEST_CODE);
    }

//    @Override
//    public void onLocationChanged(@NonNull Location location) {
//          latitude = location.getLatitude();
//          longitude = location.getLongitude();
//          findAddress();
//    }
//
//    private void findAddress() {
//        Geocoder geocoder;
//        List<Address> addresses;
//        geocoder = new Geocoder(this, Locale.getDefault());
//        try{
//            addresses = geocoder.getFromLocation(latitude,longitude,1);
//            String addresset = addresses.get(0).getAddressLine(0);
//            String cityet = addresses.get(0).getLocality();
//            String stateet = addresses.get(0).getAdminArea();
//            String countryet = addresses.get(0).getCountryName();
//            //set address
//            country.setText(countryet);
//            state.setText(stateet);
//            city.setText(cityet);
//            address1.setText(addresset);
//
//        }catch (Exception e){
//            Toast.makeText(this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    @Override
//    public void onStatusChanged(String provider, int status, Bundle extras) {
//
//    }
//
//    @Override
//    public void onProviderEnabled(@NonNull String provider) {
//
//    }
//
//    @Override
//    public void onProviderDisabled(@NonNull String provider) {
//        Toast.makeText(this, "Please turn on location", Toast.LENGTH_SHORT).show();
//    }
//
//
//
//    private boolean checkLocationPermission(){
//        boolean result = ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==
//                (PackageManager.PERMISSION_GRANTED);
//        return result;
//    }
//    private void requestLocationPermission(){
//        ActivityCompat.requestPermissions(this,locationPermissions,LOCATION_REQUEST_CODE);
//    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case CAMERA_REQUEST_CODE:{
                if(grantResults.length>0){
                    boolean cameraAccepted = grantResults[0]==PackageManager.PERMISSION_GRANTED;
                    boolean storageAccepted = grantResults[1]==PackageManager.PERMISSION_GRANTED;
                    if(cameraAccepted && storageAccepted){
                        pickFromCamera();
                    }else {
                        Toast.makeText(this, "Camera Permission is Needed....", Toast.LENGTH_LONG).show();
                    }
                }
            }
            break;
            case STORAGE_REQUEST_CODE:{
                if(grantResults.length>0){
                    boolean storageAccepted = grantResults[0]==PackageManager.PERMISSION_GRANTED;
                    if(storageAccepted){
                        pickFromGallery();
                    }else {
                        Toast.makeText(this, "Storage Permission Needed....", Toast.LENGTH_LONG).show();
                    }
                }
            }
            break;
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(resultCode== RESULT_OK){
            if(requestCode == IMAGE_PICK_GALLERY_CODE){
                image_uri = data.getData();
                profile_image.setImageURI(image_uri);
            }else if(requestCode == IMAGE_PICK_CAMERA_CODE){
                profile_image.setImageURI(image_uri);
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

}
