package com.shawon.groceryapp;

import android.widget.Filter;

import java.util.ArrayList;

public class FilterOrderShop extends Filter {

    private AdapterOrderShop adapter;
    private ArrayList<ModelOrderShop> filterList;

    public FilterOrderShop() {
    }
    public FilterOrderShop(AdapterOrderShop adapter, ArrayList<ModelOrderShop> filterList) {
        this.adapter = adapter;
        this.filterList = filterList;
    }

    @Override
    protected Filter.FilterResults performFiltering(CharSequence charSequence) {
        Filter.FilterResults results = new Filter.FilterResults();
        //validate data for search query
        if(charSequence != null && charSequence.length()>0){
            //change to upper case,to make case insensitive
            //search filed not empty, searching something ,perform search
            charSequence = charSequence.toString().toUpperCase();
            //store our filter list
            ArrayList<ModelOrderShop> filterdModels = new ArrayList<>();
            for(int i=0; i<filterList.size(); i++){
                //check , search by title and category
                if(filterList.get(i).getOrderStatus().toUpperCase().contains(charSequence)
                ) {
                    //add filtered data to list
                    filterdModels.add(filterList.get(i));

                }
            }
            results.count = filterdModels.size();
            results.values = filterdModels;
        }else {
            //search filed empty,not searching, return original/all/complete list
            results.count = filterList.size();
            results.values = filterList;
        }

        return results;
    }

    @Override
    protected void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
        adapter.orderShopArrayList = (ArrayList<ModelOrderShop>) filterResults.values;
        //refresh adapter
        adapter.notifyDataSetChanged();

    }


}

