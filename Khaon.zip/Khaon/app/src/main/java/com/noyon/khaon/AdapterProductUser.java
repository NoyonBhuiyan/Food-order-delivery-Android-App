package com.shawon.groceryapp;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import p32929.androideasysql_library.Column;
import p32929.androideasysql_library.EasyDB;

public class AdapterProductUser extends RecyclerView.Adapter<AdapterProductUser.HolderProductUser> implements Filterable {
    private Context context;
    public ArrayList<ModelProduct> productsList,filterList;
    private FilterProductUser filter;

    public AdapterProductUser(Context context, ArrayList<ModelProduct> productsList) {
        this.context = context;
        this.productsList = productsList;
        this.filterList = productsList;
    }

    @NonNull
    @Override
    public HolderProductUser onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.row_product_user,parent,false);
        return new HolderProductUser(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderProductUser holder, int position) {
        final ModelProduct modelProduct = productsList.get(position);
        String discountAvailable = modelProduct.getDiscountAvailable();
        String discountPrice = modelProduct.getDiscountPrice();
        String discountNote = modelProduct.getDiscountNote();
        String originalPrice = modelProduct.getOriginalPrice();
        String productCategory = modelProduct.getProductCategory();
        String productDescription = modelProduct.getProductDescription();
        String productIcon = modelProduct.getProductIcon();
        String productTitle = modelProduct.getProductTitle();
        String productQuantity = modelProduct.getProductQuantity();
        String timestamp = modelProduct.getTimestamp();
        String productId = modelProduct.getProductId();
        //set data
        holder.titleTv.setText(productTitle);
        holder.discountedNoteTv.setText(discountNote);
        holder.descriptionTv.setText(productDescription);
        holder.originalPriceTv.setText("TK"+""+originalPrice);
        holder.discountedPriceTv.setText("TK"+""+discountPrice);

        if(discountAvailable.equals("true")){
            //product is on discount
            holder.discountedPriceTv.setVisibility(View.VISIBLE);
            holder.discountedNoteTv.setVisibility(View.VISIBLE);
            holder.originalPriceTv.setPaintFlags(holder.originalPriceTv.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG); // ADD Strike through on original price
        }else {
            // product is not on discount
            holder.discountedPriceTv.setVisibility(View.GONE);
            holder.discountedNoteTv.setVisibility(View.GONE);
            holder.originalPriceTv.setPaintFlags(0);
        }
        try{
            Picasso.get().load(productIcon).placeholder(R.drawable.ic_add_cart_pink).into(holder.productIconIv);

        }catch (Exception e){
            holder.productIconIv.setImageResource(R.drawable.ic_add_cart_pink);
        }
        holder.addToCartTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 //add product to card
                showQuantityDialog(modelProduct);
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //show products details
            }
        });


    }

    private double cost =0;
    private double finalCost =0;
    private int quantity=0;
    private void showQuantityDialog(ModelProduct modelProduct) {
        View v = LayoutInflater.from(context).inflate(R.layout.dialog_quantity,null);
        //init layout views
        ImageView productIv = v.findViewById(R.id.productIv);
        final TextView titleTv = v.findViewById(R.id.titleTv);
        TextView pQuantityTv = v.findViewById(R.id.pQuantityTv);
        TextView descriptionTv = v.findViewById(R.id.descriptionTv);
        TextView discountedNoteTv = v.findViewById(R.id.discountedNoteTvTv);
        final TextView originalPriceTv = v.findViewById(R.id.originalPriceTv);
        TextView discountedPriceTv = v.findViewById(R.id.discountedPriceTv);
        final TextView finalTv = v.findViewById(R.id.finalTv);
        final TextView quantityTv = v.findViewById(R.id.quantityTv);
        ImageButton decrementBtn = v.findViewById(R.id.decrementBtn);
        ImageButton incrementBtn = v.findViewById(R.id.incrementBtn);
        Button continueBtn = v.findViewById(R.id.continueBtn);

        // get data from model
        final String productId = modelProduct.getProductId();
        String productTitle = modelProduct.getProductTitle();
        String productQuantity = modelProduct.getProductQuantity();
        String productDescription = modelProduct.getProductDescription();
        String discountNote = modelProduct.getDiscountNote();
        String image = modelProduct.getProductIcon();

        final String price;

        if(modelProduct.getDiscountAvailable().equals("true")){
            // product have discounted
            price = modelProduct.getDiscountPrice();
            discountedNoteTv.setVisibility(View.VISIBLE);
           originalPriceTv.setPaintFlags(originalPriceTv.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }else{
            //product don't have discounted
            discountedNoteTv.setVisibility(View.GONE);
            discountedPriceTv.setVisibility(View.GONE);
            price = modelProduct.getOriginalPrice();
        }
        cost = Double.parseDouble(price.replaceAll("TK",""));
        finalCost = Double.parseDouble(price.replaceAll("TK",""));
        quantity=1;
        //dialoag
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(v);

        //set data
        try{
            Picasso.get().load(image).placeholder(R.drawable.ic_add_cart_white).into(productIv);
        }catch (Exception e){
            productIv.setImageResource(R.drawable.ic_person_white);
        }
        titleTv.setText(""+productTitle);
        pQuantityTv.setText(""+productQuantity);
        descriptionTv.setText(""+productDescription);
        discountedNoteTv.setText(""+discountNote);
        quantityTv.setText(""+quantity);
        originalPriceTv.setText("TK"+modelProduct.getOriginalPrice());
        discountedPriceTv.setText("TK"+modelProduct.getDiscountPrice());
        finalTv.setText("TK"+finalCost);

        final AlertDialog dialog = builder.create();
        dialog.show();
        incrementBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finalCost = finalCost + cost;
                quantity++;
                finalTv.setText("TK"+finalCost);
                quantityTv.setText(""+quantity);
            }
        });
        decrementBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(quantity>1){
                    finalCost = finalCost- cost;
                    quantity--;
                    finalTv.setText("TK"+finalCost);
                    quantityTv.setText(""+quantity);
                }
            }
        });
        continueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = titleTv.getText().toString().trim();
                String priceEach = price;
                String toTalPrice = finalTv.getText().toString().trim().replace("TK","");
                String quantity = quantityTv.getText().toString().trim();

                addToCart(productId,title,priceEach,toTalPrice,quantity);

                dialog.dismiss();
            }
        });

    }

    private int itemId =1;
    private void addToCart(String productId, String title, String priceEach, String price, String quantity) {
        itemId++;
        EasyDB easyDB = EasyDB.init(context,"ITEMS_DB")
                .setTableName("ITEMS_TABLE")
                .addColumn(new Column("Item_Id",new String[]{"text","unique"}))
                .addColumn(new Column("Item_PID",new String[]{"text","not null"}))
                .addColumn(new Column("Item_Name",new String[]{"text","not null"}))
                .addColumn(new Column("Item_Price_Each",new String[]{"text","not null"}))
                .addColumn(new Column("Item_Price",new String[]{"text","not null"}))
                .addColumn(new Column("Item_Quantity",new String[]{"text","not null"}))
                .doneTableColumn();

        Boolean b = easyDB.addData("Item_Id",itemId)
                .addData("Item_PID",productId)
                .addData("Item_Name",title)
                .addData("Item_Price_Each",priceEach)
                .addData("Item_Price",price)
                .addData("Item_Quantity",quantity)
                .doneDataAdding();

        Toast.makeText(context, "Added to Cart....", Toast.LENGTH_SHORT).show();

        ((ShopDetailsActivity)context).cartCount();

    }

    @Override
    public int getItemCount() {
        return productsList.size();
    }

    @Override
    public Filter getFilter() {
        if(filter==null){
            filter = new FilterProductUser(this,filterList);
        }
        return filter;
    }


    class HolderProductUser extends RecyclerView.ViewHolder{

        //view ui
        private ImageView productIconIv,nextIv;
        private TextView discountedNoteTv,titleTv,descriptionTv,
                addToCartTv,discountedPriceTv,originalPriceTv;

        public HolderProductUser(@NonNull View itemView) {
            super(itemView);
            productIconIv = itemView.findViewById(R.id.productIconIv);
            nextIv = itemView.findViewById(R.id.nextIv);
            discountedNoteTv = itemView.findViewById(R.id.discountedNoteTv);
            titleTv = itemView.findViewById(R.id.titleTv);
            descriptionTv = itemView.findViewById(R.id.descriptionTv);
            addToCartTv = itemView.findViewById(R.id.addToCartTv);
            discountedPriceTv = itemView.findViewById(R.id.discountedPriceTv);
            originalPriceTv = itemView.findViewById(R.id.originalPriceTv);
        }
    }
}
