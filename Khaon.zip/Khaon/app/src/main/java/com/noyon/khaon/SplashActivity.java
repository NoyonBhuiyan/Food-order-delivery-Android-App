package com.shawon.groceryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SplashActivity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
//    ImageView imageView;
//    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash)

        //make full screen
//        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

       ;


//        imageView = (ImageView)findViewById(R.id.imageView);
//        textView = (TextView)findViewById(R.id.textView7);
//
//        imageView.animate().alpha(0f).setDuration(0);
//        textView.animate().alpha(0f).setDuration(0);

        firebaseAuth = FirebaseAuth.getInstance();

//        imageView.animate().alpha(1f).setDuration(1000).setListener(new AnimatorListenerAdapter() {
//
//            @Override
//            public void onAnimationEnd(Animator animation) {
//                textView.animate().alpha(1f).setDuration(800);
//
//            }
//        });

        //start login activity after 4sec
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
               FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
               if(firebaseUser == null){
                    Intent intent = new Intent(SplashActivity.this,LoginActivity.class);
                    startActivity(intent);
                    finish();
               }else {
                   checkUserType();
               }


            }
        },4000);
    }

    private void checkUserType() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
        ref.child(firebaseAuth.getUid())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String accountType = ""+dataSnapshot.child("accountType").getValue();
                        if(accountType.equals("Seller")){
                            Intent intent =new Intent(SplashActivity.this,MainSellerActivity.class);
                            startActivity(intent);
                        }else {
                            Intent intent =new Intent(SplashActivity.this,MainUserActivity.class);
                            startActivity(intent);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }
}
