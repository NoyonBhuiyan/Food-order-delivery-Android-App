package com.shawon.groceryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterPromotionShop  extends RecyclerView.Adapter<AdapterPromotionShop.HolderPromotionShop>{

    private Context context;
    private ArrayList<ModelPromotion> promotionArrayList;

    public AdapterPromotionShop(PromotionCodesActivity promotionCodesActivity, ArrayList<ModelPromotion> promotionArrayList) {
        this.promotionArrayList = promotionArrayList;
    }

    @NonNull
    @Override
    public HolderPromotionShop onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view= LayoutInflater.from( context ).inflate( R.layout.row_promotion_shop,parent, false );

        return new HolderPromotionShop( view );
    }

    @Override
    public void onBindViewHolder(@NonNull HolderPromotionShop holder, int position) {

       ModelPromotion modelPromotion= promotionArrayList.get( position );
       String id= modelPromotion.getId();
        String timestamp= modelPromotion.getTimestamp();
        String description= modelPromotion.getDescription();
        String promoCode= modelPromotion.getPromoCode();
        String promoPrice= modelPromotion.getPromoPrice();
        String mimimumOrderPrice= modelPromotion.getMimimumOrderPrice();
        String expireDate= modelPromotion.getExpireDate();

        holder.descriptionTv.setText( description );
        holder.promoPriceTv.setText( promoPrice );
        holder.minimumOrderPriceTv.setText( mimimumOrderPrice );
        holder.promoCodeTv.setText("Code:"+ promoCode );
        holder.expireDateTv.setText("Expire Date"+ expireDate );


    }

    @Override
    public int getItemCount() {
        return promotionArrayList.size();
    }

    class HolderPromotionShop extends RecyclerView.ViewHolder{

private ImageView iconIv;
private TextView promoCodeTv,promoPriceTv,minimumOrderPriceTv,expireDateTv,descriptionTv;


        public HolderPromotionShop(@NonNull View itemView) {
            super( itemView );

            iconIv= itemView.findViewById( R.id.iconIv );
            promoCodeTv= itemView.findViewById( R.id.promoCodeTv );
            promoPriceTv= itemView.findViewById( R.id.promoPriceTv );
            minimumOrderPriceTv= itemView.findViewById( R.id.minimumOrderPriceTv );
            expireDateTv= itemView.findViewById( R.id.expireDateTv );
            descriptionTv= itemView.findViewById( R.id.descriptionTv );
        }
    }
}
